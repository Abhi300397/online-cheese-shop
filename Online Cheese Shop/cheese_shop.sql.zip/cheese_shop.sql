-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 04, 2021 at 09:23 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cheese_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `customerId`, `productId`, `size`, `qty`, `price`) VALUES
(34, 11, 14, 200, 3, 24.6);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `name`, `email`, `password`) VALUES
(1, 'Abhi', 'vabhi@gmail.com', 'pbkdf2:sha256:260000$e9BWuyU7Kvui3xMR$264b03319efdd346d3a3fb786c5a5dea17b28f6c38b1f1226b064c8095a0a72a'),
(2, 'Abi', 'abi@gmail.com', 'pbkdf2:sha256:260000$H5wRchoiClnV4R3X$4c32e4d3e67cb9b17e5bd1447bd1ea61c489f82736add24d6986e1dcca3c594b'),
(4, 'Abhilash', 'vabhi30@gmail.com', 'pbkdf2:sha256:260000$OovUYEVld4zSmmH0$02d86dc60866cdab2e48649290cb9737d575b3c0bff5b6f7b0fc5c7fb97f6745'),
(5, 'Abhilash30', 'abi30@gmail.com', 'pbkdf2:sha256:260000$6NmzOBcqaPwFfkTW$43def08baae02f63a5c9c0a8c57aa8ab2f9d56c162ee4e9d7ad4b4769a86a691'),
(6, 'Abhi12', 'vabhi12@gmail.com', 'pbkdf2:sha256:260000$iJFSDOLDooIAVw9S$3c67715ee79b30169831681510a452b7de451a83aedd6442180c06572775df6b'),
(7, 'Abhilash303', 'vabhi303@gmail.com', 'pbkdf2:sha256:260000$kp4zAizqOMNINOIk$79e1883a168a841e58cabb2e8a02a3fe0eff53f78bacd9e7878762a8343c7fae'),
(8, 'Tom', 'tom123@gmail.com', 'pbkdf2:sha256:260000$QlVhhFKzfgffl1Fg$78937fdd94d552b1f0e0b75c482e2eb1c983fa950415b064f3dbf551cb78c8ee'),
(9, 'Hardy', 'hardy123@gmail.com', 'pbkdf2:sha256:260000$QL0CJdDwd1EUdYxq$690ca15b86aab8ee2bf4a1e781136af216c4fb1ead73861c47d560deb1bd6a7a'),
(10, 'Harry', 'harry123@gmail.com', 'pbkdf2:sha256:260000$fyTvdS2l8tdhAg8I$01712f9ed879f2819dd1ee0d8669975433596be9b8d55946f69aad2c16e31749'),
(11, 'Ron', 'ron123@gmail.com', 'pbkdf2:sha256:260000$PDDEhmAlZQ7R71Mu$0aa3d30d25292ad114922c6fdaeb748a65ad72800cd11005149dcad4a40a9273'),
(12, 'Ronny', 'ronny123@gmail.com', 'pbkdf2:sha256:260000$W1LMjDbjUGgcSKaS$d799a6780fb9313ef8cdce6bb583b00429ae3ceee367fcd174b16878c84531a5'),
(13, 'White', 'white123@gmail.com', 'pbkdf2:sha256:260000$nE9o9wmRi8nSRGPq$76dc581fcfeb4be8dd5e5e74d318603013b9ebd9c0dcfa84657e42931d4feaea');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeID` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employeeID`, `name`, `email`, `password`) VALUES
(1, 'Sam', 'sam@gmail.com', 'pbkdf2:sha256:260000$5tIAs77I65gksewk$ccf8a63600f3c5a469a0ea4390f17302ff2d51b2ef5aa9d7d14d0611d27f337a');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `datePlaced` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `customerId`, `datePlaced`, `total`) VALUES
(60, 1, '2021-08-04 13:45:11', 9),
(61, 1, '2021-08-04 14:03:26', 4.25),
(62, 1, '2021-08-04 14:09:39', 5),
(63, 1, '2021-08-04 20:37:53', 5),
(64, 1, '2021-08-04 23:35:14', 147),
(65, 1, '2021-08-04 23:37:19', 69.6),
(66, 1, '2021-08-05 01:03:44', 93.9),
(67, 5, '2021-08-05 01:13:38', 8.8),
(68, 5, '2021-08-05 01:14:09', 22.1),
(69, 7, '2021-08-05 01:28:16', 30.2),
(70, 8, '2021-08-05 01:54:38', 30.7),
(71, 9, '2021-08-05 02:07:18', 20.7),
(72, 10, '2021-08-05 02:14:32', 25.3),
(73, 12, '2021-08-05 02:37:04', 18.9),
(74, 13, '2021-08-05 02:41:53', 12.5);

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `productId` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `orderId`, `productId`, `size`, `qty`, `price`) VALUES
(88, 61, 7, 100, 1, 3.25),
(90, 62, 1, 100, 5, 5),
(91, 63, 3, 100, 2, 5),
(92, 64, 2, 500, 1, 4.5),
(93, 64, 2, 200, 2, 3.6),
(94, 64, 2, 100, 7, 6.3),
(95, 64, 3, 500, 6, 75),
(96, 64, 11, 300, 6, 57.6),
(99, 65, 2, 300, 3, 8.1),
(100, 65, 14, 500, 3, 61.5),
(102, 66, 14, 200, 2, 16.4),
(103, 66, 19, 200, 4, 40),
(104, 66, 3, 500, 3, 37.5),
(105, 67, 13, 100, 2, 3.8),
(106, 67, 3, 100, 2, 5),
(108, 68, 2, 300, 3, 8.1),
(109, 68, 5, 200, 4, 14),
(111, 69, 13, 100, 3, 5.7),
(112, 69, 4, 200, 2, 12),
(113, 69, 3, 500, 1, 12.5),
(114, 70, 13, 100, 3, 5.7),
(115, 70, 3, 500, 2, 25),
(117, 71, 13, 100, 3, 5.7),
(118, 71, 3, 200, 3, 15),
(120, 72, 11, 200, 2, 12.8),
(121, 72, 3, 500, 1, 12.5),
(123, 73, 2, 300, 7, 18.9),
(124, 74, 3, 500, 1, 12.5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productId` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `img` varchar(60) NOT NULL,
  `categoryMilk` varchar(30) NOT NULL,
  `origin` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `isDeleted` tinyint(1) NOT NULL DEFAULT '0',
  `qty100` int(11) NOT NULL DEFAULT '0',
  `qty200` int(11) NOT NULL DEFAULT '0',
  `qty300` int(11) NOT NULL DEFAULT '0',
  `qty500` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productId`, `name`, `img`, `categoryMilk`, `origin`, `type`, `price`, `isDeleted`, `qty100`, `qty200`, `qty300`, `qty500`) VALUES
(1, 'Asiago', 'asiago.jpg', 'Cow', 'Italy', 'Hard', 1, 0, 10, 15, 19, 20),
(2, 'Brie', 'brie.jpg', 'Sheep', 'France', 'Soft-ripened', 0.9, 0, 13, 18, 20, 20),
(3, 'Burrata', 'burrata.jpg', 'Cow', 'Italy', 'Fresh soft', 2.5, 0, 14, 15, 20, 0),
(4, 'Camembert', 'camembert.jpg', 'Sheep', 'France', 'Soft-ripened', 3, 0, 17, 18, 20, 20),
(5, 'Cheddar', 'chedar.jpg', 'Cow', 'England', 'Hard', 1.75, 0, 20, 10, 17, 5),
(6, 'Cottage Cheese', 'cottage.jpg', 'Cow', 'America', 'Soft', 2, 0, 15, 15, 10, 10),
(7, 'Cream Cheese', 'cream_cheese.jpg', 'Cow', 'America', 'Fresh soft', 3.25, 0, 18, 20, 20, 10),
(8, 'Edam', 'edam.jpg', 'Cow', 'Netherlands', 'Semi-hard', 3, 0, 5, 1, 5, 5),
(9, 'Feta', 'feta.jpg', 'Sheep', 'Greece', 'Soft', 2.25, 0, 12, 24, 15, 10),
(10, 'Gorgonzola', 'gorgonzola.jpg', 'Cow', 'Italy', 'Hard', 1, 0, 10, 10, 10, 20),
(11, 'Gouda', 'gouda.jpg', 'Cow', 'Netherlands', 'Semi-hard', 3.2, 0, 15, 13, 1, 10),
(12, 'Grana Padano', 'grana_padano.jpg', 'Cow', 'Italy', 'Crumbly', 3.3, 0, 15, 15, 15, 10),
(13, 'Halloumi', 'halloumi.jpg', 'Sheep', 'Middle East', 'Semi-soft', 1.9, 0, 4, 15, 15, 10),
(14, 'Havarti', 'Havarti.jpg', 'Cow', 'Denmark', 'Semi-soft', 4.1, 0, 10, 18, 10, 7),
(15, 'Manchego', 'manchego.jpg', 'Sheep', 'Spain', 'Semi-soft', 4.23, 0, 20, 20, 20, 10),
(16, 'Monterey Jack', 'monterey_jack.jpg', 'Cow', 'America', 'Semi-hard', 3.7, 0, 13, 20, 15, 15),
(17, 'Mozzarella', 'mozzrella.jpg', 'Cow', 'Italy', 'Semi-soft', 2.6, 0, 20, 20, 20, 0),
(18, 'Parmigiano Reggiano', 'parmigiano_reggiano.jpg', 'Sheep', 'Italy', 'Hard', 3.1, 0, 15, 15, 15, 10),
(19, 'Provolone', 'provolone.jpg', 'Sheep', 'Italy', 'Semi-hard', 5, 0, 20, 6, 10, 10),
(21, 'Ricotta', 'ricotta.jpg', 'Cow', 'Italy', 'Fresh soft', 4.7, 0, 0, 20, 0, 0),
(22, 'Swiss Cheese', 'swiss_cheese.jpg', 'Cow', 'Switzerland', 'Hard', 4, 0, 20, 20, 20, 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerId` (`customerId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeID`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerId` (`customerId`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerID`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`productId`);

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerID`);

--
-- Constraints for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD CONSTRAINT `orderitems_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orderdetails` (`id`),
  ADD CONSTRAINT `orderitems_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`productId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
